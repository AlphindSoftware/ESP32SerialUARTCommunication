# ESP32SerialUARTCommunication
UART Communication between two ESP32 boards
